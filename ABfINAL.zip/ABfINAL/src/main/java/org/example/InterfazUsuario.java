package org.example;

// Interfaz para manejar la entrada/salida de mensajes
public interface InterfazUsuario {
    void mostrarMensaje(String mensaje);
    int leerEntero();
}